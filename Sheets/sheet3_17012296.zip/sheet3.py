import numpy as np
import matplotlib.pyplot as plt
from math import factorial


def graph(steps, formula, curves):
    one_step = 1/steps
    x, y = np.array([]), np.array([])
    for piece in curves:
        t = np.arange(0, 1+one_step, one_step)
        x1, y1 = formula(t, piece)
        x = np.concatenate((x, x1))
        y = np.concatenate((y, y1))
    plt.figure(figsize=(8, 8))
    plt.plot(origin[0], origin[1], 'X', color='red')
    plt.plot(x, y)
    plt.show()


def cubic_bezier(t, points):
    return cubic_bezier_x(t, points), cubic_bezier_y(t, points)


def cubic_bezier_x(t, x):
    return (1-t)**3*x[0][0]+3*t*(1-t)**2*x[1][0]+3*t**2*(1-t)*x[2][0]+t**3*x[3][0]


def cubic_bezier_y(t, y):
    return (1-t)**3*y[0][1]+3*t*(1-t)**2*y[1][1]+3*t**2*(1-t)*y[2][1]+t**3*y[3][1]


def comb(n, k):
    return factorial(n) // (factorial(k) * factorial(n - k))


def get_bezier_curve(points):
    n = len(points) - 1
    return lambda t: sum(
        comb(n, i) * t**i * (1 - t)**(n - i) * points[i]
        for i in range(n + 1)
    )


def evaluate_bezier(points, total):
    bezier = get_bezier_curve(points)
    new_points = np.array([bezier(t) for t in np.linspace(0, 1, total)])
    return new_points[:, 0], new_points[:, 1]


origin = (100, 100)
radius = 90
p0 = (100, 10)
p1 = (150, 10)
p2 = (190, 50)
p3 = (190, 100)
p4 = (190, 100)
p5 = (190, 150)
p6 = (150, 190)
p7 = (100, 190)
p8 = (100, 190)
p9 = (50, 190)
p10 = (10, 150)
p11 = (10, 100)
p12 = (10, 100)
p13 = (10, 50)
p14 = (50, 10)
p15 = (100, 10)

steps = 50

piece1 = [p0, p1, p2, p3]
piece2 = [p4, p5, p6, p7]
piece3 = [p8, p9, p10, p11]
piece4 = [p12, p13, p14, p15]

curves = [piece1, piece2, piece3, piece4]

# Question 1 i)
# 4 Pieces
graph(steps, cubic_bezier, curves)

# Question 1 ii)
# 13 Control Points
plt.figure(figsize=(8, 8))
one_curve = np.array([p0, p1, p2, p3, p5, p6, p7, p9, p10, p11, p13, p14, p15])
x, y = one_curve[:, 0], one_curve[:, 1]
bx, by = evaluate_bezier(one_curve, steps)
plt.plot(bx, by, 'b-')
plt.plot(x, y, 'r.')
plt.show()

# Question 1 iii)
# Built in Circle
circle = plt.Circle(origin, radius, color='r', fill=False)
plt.figure(figsize=(8, 8))
plt.plot(origin[0], origin[1], 'X', color='blue')
fig = plt.gcf()
ax = fig.gca()
ax.set_xlim((0, 200))
ax.set_ylim((0, 200))
ax.add_patch(circle)
fig.savefig('plotcircles.png')

# Question 1 iv)
# Moving P1 up and down
plt.figure(figsize=(8, 8))
p1 = (150, -100)
piece1 = [p0, p1, p2, p3]
piece2 = [p4, p5, p6, p7]
piece3 = [p8, p9, p10, p11]
piece4 = [p12, p13, p14, p15]
curves = [piece1, piece2, piece3, piece4]
graph(steps, cubic_bezier, curves)

plt.figure(figsize=(8, 8))
one_curve = np.array([p0, p1, p2, p3, p5, p6, p7, p9, p10, p11, p13, p14, p15])
x, y = one_curve[:, 0], one_curve[:, 1]
bx, by = evaluate_bezier(one_curve, steps)
plt.plot(bx, by, 'b-')
plt.plot(x, y, 'r.')
plt.show()

plt.figure(figsize=(8, 8))
p1 = (150, 100)
piece1 = [p0, p1, p2, p3]
piece2 = [p4, p5, p6, p7]
piece3 = [p8, p9, p10, p11]
piece4 = [p12, p13, p14, p15]
curves = [piece1, piece2, piece3, piece4]
graph(steps, cubic_bezier, curves)

plt.figure(figsize=(8, 8))
one_curve = np.array([p0, p1, p2, p3, p5, p6, p7, p9, p10, p11, p13, p14, p15])
x, y = one_curve[:, 0], one_curve[:, 1]
bx, by = evaluate_bezier(one_curve, steps)
plt.plot(bx, by, 'b-')
plt.plot(x, y, 'r.')
plt.show()
